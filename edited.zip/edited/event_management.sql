-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2024 at 08:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_event` (IN `p_event_name` VARCHAR(250), IN `p_event_date` DATE, IN `p_event_location` VARCHAR(250), IN `p_event_description` VARCHAR(250), IN `p_name_re` VARCHAR(250))   BEGIN
    DECLARE v_error_message VARCHAR(255);

 
    START TRANSACTION;

    
    IF (LENGTH(p_event_name) > 20 OR LENGTH(p_event_location) > 20 OR LENGTH(p_name_re) > 20 OR LENGTH(p_event_description) > 50) THEN
        SET v_error_message = 'The provided event details exceed the maximum allowed length of 20 characters. The transaction has been rolled back';
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_message;
    ELSE
     
        INSERT INTO events (event_name, event_date, event_location, event_description, name_re)
        VALUES (p_event_name, p_event_date, p_event_location, p_event_description, p_name_re);


        COMMIT;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_event` (IN `p_event_id` INT)   BEGIN
    DELETE FROM events
    WHERE event_id = p_event_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_event` (IN `p_event_id` INT, IN `p_event_name` VARCHAR(20), IN `p_event_location` VARCHAR(50), IN `p_event_description` TEXT, IN `p_name_re` VARCHAR(20))   BEGIN
    UPDATE events
    SET event_name = p_event_name, event_location = p_event_location, event_description = p_event_description, name_re = p_name_re
    WHERE event_id = p_event_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `eventparticipants`
--

CREATE TABLE `eventparticipants` (
  `participant_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `participant_name` varchar(100) DEFAULT NULL,
  `participant_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eventparticipants`
--

INSERT INTO `eventparticipants` (`participant_id`, `event_id`, `participant_name`, `participant_email`) VALUES
(5, 2, 'micheal umapas', 'micheal@gmail.com'),
(6, 3, 'rendel', 'rendel@gmail.com'),
(11, 1, 'Alice Johnson', 'alice.johnson@example.com'),
(12, 1, 'Bob Smith', 'bob.smith@example.com'),
(13, 2, 'Charlie Brown', 'charlie.brown@example.com'),
(14, 2, 'Daisy Miller', 'daisy.miller@example.com'),
(15, 3, 'Ella Davis', 'ella.davis@example.com'),
(16, 3, 'Frank Wilson', 'frank.wilson@example.com'),
(17, 4, 'Grace Lee', 'grace.lee@example.com'),
(18, 4, 'Henry Clark', 'henry.clark@example.com'),
(19, 5, 'Isabel White', 'isabel.white@example.com'),
(20, 5, 'Jack Harris', 'jack.harris@example.com'),
(21, 6, 'Kelly Green', 'kelly.green@example.com'),
(22, 6, 'Liam Taylor', 'liam.taylor@example.com'),
(23, 7, 'Mia Anderson', 'mia.anderson@example.com'),
(24, 7, 'Noah Martinez', 'noah.martinez@example.com'),
(25, 8, 'Olivia Brown', 'olivia.brown@example.com'),
(26, 8, 'Peter Garcia', 'peter.garcia@example.com'),
(27, 1, 'Alice Johnson', 'alice.johnson1@example.com'),
(28, 1, 'Bob Smith', 'bob.smith1@example.com'),
(29, 1, 'Charlie Brown', 'charlie.brown1@example.com'),
(30, 1, 'Daisy Miller', 'daisy.miller1@example.com'),
(31, 1, 'Ella Davis', 'ella.davis1@example.com'),
(32, 1, 'Frank Wilson', 'frank.wilson1@example.com'),
(33, 1, 'Grace Lee', 'grace.lee1@example.com'),
(34, 1, 'Henry Clark', 'henry.clark1@example.com'),
(35, 1, 'Isabel White', 'isabel.white1@example.com'),
(36, 1, 'Jack Harris', 'jack.harris1@example.com'),
(37, 2, 'Kelly Green', 'kelly.green2@example.com'),
(38, 2, 'Liam Taylor', 'liam.taylor2@example.com'),
(39, 2, 'Mia Anderson', 'mia.anderson2@example.com'),
(40, 2, 'Noah Martinez', 'noah.martinez2@example.com'),
(41, 2, 'Olivia Brown', 'olivia.brown2@example.com'),
(42, 2, 'Peter Garcia', 'peter.garcia2@example.com'),
(43, 2, 'Quinn Wilson', 'quinn.wilson2@example.com'),
(44, 2, 'Rachel Adams', 'rachel.adams2@example.com'),
(45, 2, 'Samuel Evans', 'samuel.evans2@example.com'),
(46, 2, 'Tina Cooper', 'tina.cooper2@example.com'),
(47, 3, 'Victor Reed', 'victor.reed3@example.com'),
(48, 3, 'Wendy Parker', 'wendy.parker3@example.com'),
(49, 3, 'Xavier Hill', 'xavier.hill3@example.com'),
(50, 3, 'Yvonne Brooks', 'yvonne.brooks3@example.com'),
(51, 3, 'Zachary Turner', 'zachary.turner3@example.com'),
(52, 3, 'Abigail Scott', 'abigail.scott3@example.com'),
(53, 3, 'Benjamin Ward', 'benjamin.ward3@example.com'),
(54, 3, 'Caroline Gray', 'caroline.gray3@example.com'),
(55, 3, 'Daniel Fisher', 'daniel.fisher3@example.com'),
(56, 3, 'Emily Price', 'emily.price3@example.com'),
(57, 4, 'Finn Murphy', 'finn.murphy4@example.com'),
(58, 4, 'Georgia Bell', 'georgia.bell4@example.com'),
(59, 4, 'Harry Young', 'harry.young4@example.com'),
(60, 4, 'Isabella King', 'isabella.king4@example.com'),
(61, 4, 'Jacob Lopez', 'jacob.lopez4@example.com'),
(62, 4, 'Katherine Reed', 'katherine.reed4@example.com'),
(63, 4, 'Landon Morris', 'landon.morris4@example.com'),
(64, 4, 'Molly Ward', 'molly.ward4@example.com'),
(65, 4, 'Nathan Green', 'nathan.green4@example.com'),
(66, 4, 'Olivia Hill', 'olivia.hill4@example.com'),
(67, 5, 'Patrick Adams', 'patrick.adams5@example.com'),
(68, 5, 'Quincy Baker', 'quincy.baker5@example.com'),
(69, 5, 'Rachel Carter', 'rachel.carter5@example.com'),
(70, 5, 'Samuel Davis', 'samuel.davis5@example.com'),
(71, 5, 'Tiffany Evans', 'tiffany.evans5@example.com'),
(72, 5, 'Ulysses Foster', 'ulysses.foster5@example.com'),
(73, 5, 'Victoria Garcia', 'victoria.garcia5@example.com'),
(74, 5, 'William Hughes', 'william.hughes5@example.com'),
(75, 5, 'Xavier Ingram', 'xavier.ingram5@example.com'),
(76, 5, 'Yolanda Jackson', 'yolanda.jackson5@example.com'),
(77, 6, 'Zane Kelly', 'zane.kelly6@example.com'),
(78, 6, 'Amelia Lopez', 'amelia.lopez6@example.com'),
(79, 6, 'Brian Mitchell', 'brian.mitchell6@example.com'),
(80, 6, 'Catherine Nelson', 'catherine.nelson6@example.com'),
(81, 6, 'David Olson', 'david.olson6@example.com'),
(82, 6, 'Emma Parker', 'emma.parker6@example.com'),
(83, 6, 'Felix Quinn', 'felix.quinn6@example.com'),
(84, 6, 'Grace Roberts', 'grace.roberts6@example.com'),
(85, 6, 'Henry Smith', 'henry.smith6@example.com'),
(86, 6, 'Isabel Thompson', 'isabel.thompson6@example.com'),
(87, 7, 'Jackie Underwood', 'jackie.underwood7@example.com'),
(88, 7, 'Kevin Vaughn', 'kevin.vaughn7@example.com'),
(89, 7, 'Linda Walsh', 'linda.walsh7@example.com'),
(90, 7, 'Michael Xavier', 'michael.xavier7@example.com'),
(91, 7, 'Nancy Young', 'nancy.young7@example.com'),
(92, 7, 'Oliver Zimmerman', 'oliver.zimmerman7@example.com'),
(93, 7, 'Penelope Adams', 'penelope.adams7@example.com'),
(94, 7, 'Quentin Brown', 'quentin.brown7@example.com'),
(95, 7, 'Rachel Campbell', 'rachel.campbell7@example.com'),
(96, 7, 'Steven Davis', 'steven.davis7@example.com'),
(97, 8, 'Tina Edwards', 'tina.edwards8@example.com'),
(98, 8, 'Ulysses Foster', 'ulysses.foster8@example.com'),
(99, 8, 'Victoria Garcia', 'victoria.garcia8@example.com'),
(100, 8, 'William Hughes', 'william.hughes8@example.com'),
(101, 8, 'Xavier Ingram', 'xavier.ingram8@example.com'),
(102, 8, 'Yolanda Jackson', 'yolanda.jackson8@example.com'),
(103, 8, 'Zane Kelly', 'zane.kelly8@example.com'),
(104, 8, 'Amelia Lopez', 'amelia.lopez8@example.com'),
(105, 8, 'Brian Mitchell', 'brian.mitchell8@example.com'),
(106, 8, 'Catherine Nelson', 'catherine.nelson8@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_date` date NOT NULL,
  `event_location` varchar(255) NOT NULL,
  `event_description` text DEFAULT NULL,
  `name_re` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `event_date`, `event_location`, `event_description`, `name_re`) VALUES
(1, 'FUNERAL', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on'),
(2, 'Art Exhibition', '2024-10-05', 'Art Gallery', 'Showcasing contemporary artworks by local artists.', 'Alexander Rodriguez'),
(3, 'Sports Tournament', '2024-11-12', 'Sports Complex', 'Competitive matches in various sports disciplines.', 'Emily Smith'),
(4, 'Charity Gala', '2024-12-03', 'Grand Hotel', 'Fundraising event for a charitable cause.', 'Liam Johnson'),
(5, 'Business Seminar', '2025-01-18', 'Business Center', 'Insightful sessions on entrepreneurship and business strategies.', 'Madison Williams'),
(6, 'Fashion Show', '2025-02-22', 'Fashion Mall', 'Showcasing the latest trends in fashion and design.', 'Ethan Brown'),
(7, 'Film Festival', '2025-03-30', 'Cinema Complex', 'Screening of award-winning and independent films.', 'Olivia Davis\r\n'),
(8, 'Science Fair', '2025-04-25', 'Science Museum', 'Interactive displays and demonstrations on scientific innovations.', 'Benjamin Martinez');

--
-- Triggers `events`
--
DELIMITER $$
CREATE TRIGGER `after_update_trigger` AFTER UPDATE ON `events` FOR EACH ROW BEGIN
    INSERT INTO tem_table (event_id, event_name, event_date, event_location, event_description, name_re, timestamp)
    VALUES (NEW.event_id, NEW.event_name, NEW.event_date, NEW.event_location, NEW.event_description, NEW.name_re, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `timestamp_event_date_trigger` BEFORE INSERT ON `events` FOR EACH ROW SET NEW.event_date = CURDATE()
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `event_view`
-- (See below for the actual view)
--
CREATE TABLE `event_view` (
`event_id` int(11)
,`event_name` varchar(100)
,`event_date` date
,`event_location` varchar(255)
,`event_description` text
,`name_re` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `tem_table`
--

CREATE TABLE `tem_table` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_location` varchar(255) DEFAULT NULL,
  `event_description` text DEFAULT NULL,
  `name_re` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tem_table`
--

INSERT INTO `tem_table` (`id`, `event_id`, `event_name`, `event_date`, `event_location`, `event_description`, `name_re`, `timestamp`) VALUES
(1, 1, 'Music Concert', '2024-07-15', 'City Arena', 'An evening of live music performances.', 'wwwwww', '2024-04-02 10:07:48'),
(2, 1, 'Music Concert', '2024-07-15', 'City Arena', 'An evening of live music performances.', 'rendel reyes', '2024-04-02 10:09:07'),
(3, 1, 'Music Concert', '2024-07-15', 'City Arena', 'An evening of live music performances.', 'rendel reyes', '2024-04-02 10:09:28'),
(4, 1, 'Music Concert', '2024-07-15', 'City Arena', 'An evening of live music performances.', 'rendel reyes', '2024-04-02 10:09:33'),
(5, 1, 'Music Concert', '2024-07-15', 'City Arena', 'An evening of live music performances.', 'rendel reyes', '2024-04-02 10:13:47'),
(6, 3, 'Food Festival', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-04-02 23:29:14'),
(7, 3, 'Food Festival', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-04-02 23:29:41'),
(8, 1, 'Food Festival', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-04-03 06:49:55'),
(9, 2, 'Art Exhibition', '2024-10-05', 'Art Gallery', 'Showcasing contemporary artworks by local artists.', 'Alexander Rodriguez', '2024-04-03 06:49:55'),
(10, 3, 'Sports Tournament', '2024-11-12', 'Sports Complex', 'Competitive matches in various sports disciplines.', 'Emily Smith', '2024-04-03 06:49:55'),
(11, 4, 'Charity Gala', '2024-12-03', 'Grand Hotel', 'Fundraising event for a charitable cause.', 'Liam Johnson', '2024-04-03 06:49:55'),
(12, 5, 'Business Seminar', '2025-01-18', 'Business Center', 'Insightful sessions on entrepreneurship and business strategies.', 'Madison Williams', '2024-04-03 06:49:55'),
(13, 6, 'Fashion Show', '2025-02-22', 'Fashion Mall', 'Showcasing the latest trends in fashion and design.', 'Ethan Brown', '2024-04-03 06:49:55'),
(14, 7, 'Film Festival', '2025-03-30', 'Cinema Complex', 'Screening of award-winning and independent films.', 'Olivia Davis\r\n', '2024-04-03 06:49:55'),
(15, 8, 'Science Fair', '2025-04-25', 'Science Museum', 'Interactive displays and demonstrations on scientific innovations.', 'Benjamin Martinez', '2024-04-03 06:49:55'),
(16, 9, 'birthday', '2024-04-01', 'tagum', 'big party', 'ashton', '2024-04-03 06:49:55'),
(17, 11, 'fiesta', '2024-04-07', 'kapalong', 'feista', 'ashton', '2024-04-07 11:08:27'),
(18, 11, 'fiesta', '2024-04-07', 'kapalong', 'feista', 'Mikka ella G. Pino-on', '2024-04-07 11:13:07'),
(19, 11, 'fiesta', '2024-04-07', 'kapalong', 'feista', 'Mikka ella G. gentiles', '2024-04-07 11:15:56'),
(20, 11, 'fiesta', '2024-04-07', 'kapalong', 'feista', 'Mikka ella G. Pino-on', '2024-04-08 06:41:01'),
(21, 11, 'fiesta', '2024-04-07', 'kapalong', 'funeral', 'Mikka ella G. Pino-on', '2024-06-05 00:37:53'),
(22, 9, 'birthday', '2024-04-01', 'tagum', 'big party', 'mark', '2024-06-05 02:12:15'),
(23, 1, '', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:34:05'),
(24, 1, '', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:54:42'),
(25, 1, '5454545', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:56:07'),
(26, 1, 'FUNERAL', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:56:38'),
(27, 1, 'askhjhslahxlfhlahslxgljanlsxlgnlansljfx', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:59:27'),
(28, 1, 'askaksnfnlkansfclknlkahcghoxhalsx nlgjbacghagbxjsahrc', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:59:46'),
(29, 1, 'FUNERAL', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 05:59:56'),
(30, 1, 'askjcgiahxiasxnalc ht haxjbsxkbaksjbxkghbv ahbxhkbsa xf', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 06:00:31'),
(31, 1, 'FUNERAL', '2024-09-10', 'Downtown Park', 'A celebration of diverse cuisines and culinary experiences.', 'ashton Mark Pino-on', '2024-06-05 06:00:42');

-- --------------------------------------------------------

--
-- Structure for view `event_view`
--
DROP TABLE IF EXISTS `event_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `event_view`  AS SELECT `events`.`event_id` AS `event_id`, `events`.`event_name` AS `event_name`, `events`.`event_date` AS `event_date`, `events`.`event_location` AS `event_location`, `events`.`event_description` AS `event_description`, `events`.`name_re` AS `name_re` FROM `events` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eventparticipants`
--
ALTER TABLE `eventparticipants`
  ADD PRIMARY KEY (`participant_id`),
  ADD KEY `fk_event_id` (`event_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `id_event_date` (`event_date`);

--
-- Indexes for table `tem_table`
--
ALTER TABLE `tem_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tem_table`
--
ALTER TABLE `tem_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `eventparticipants`
--
ALTER TABLE `eventparticipants`
  ADD CONSTRAINT `eventparticipants_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_event_id` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
