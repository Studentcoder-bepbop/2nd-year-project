<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event_management";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['add_event'])) {
            // Handle adding an event
            $p_event_name = $_POST['event_name'] ?? '';
            $p_event_date = $_POST['event_date'] ?? '';
            $p_event_location = $_POST['event_location'] ?? '';
            $p_event_description = $_POST['event_description'] ?? '';
            $p_name_re = $_POST['name_re'] ?? '';

            $stmt_add = $conn->prepare("CALL add_event(?, ?, ?, ?, ?)");
            $stmt_add->bind_param("sssss", $p_event_name, $p_event_date, $p_event_location, $p_event_description, $p_name_re);

            if ($stmt_add->execute()) {
                echo "";
            } else {
                echo "Error adding event: " . $conn->error;
            }
            $stmt_add->close();
        } elseif (isset($_POST['delete_event'])) {
            // delete event
            $event_id = $_POST['event_id'] ?? '';

           
            $stmt_delete = $conn->prepare("DELETE FROM events WHERE event_id = ?");
            $stmt_delete->bind_param("i", $event_id);

            if ($stmt_delete->execute()) {
                echo "";
            } else {
                echo "Error deleting event: " . $stmt_delete->error;
            }
            $stmt_delete->close();
        } 
    }
} catch (Exception $e) {
    $conn->rollback();
    echo "An error occurred: " . $e->getMessage();
}




$search_query = "";
if (isset($_POST['search'])) {
    $search_query = $_POST['search'];
}

$sql = "SELECT * FROM event_view WHERE name_re LIKE '%$search_query%'";

$result = $conn->query($sql);
;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    
</head>
<body>
    
<form action="" method="post" class="left">
<h2>ADD EVENT</h2>
        <label for="event_name">Event Name:</label><br>
        <input type="text" id="event_name" name="event_name"><br><br>
        
        <label for="event_location">Event Location:</label><br>
        <input type="text" id="event_location" name="event_location"><br><br>
        
        <label for="event_description">Event Description:</label><br>
        <textarea id="event_description" name="event_description"></textarea><br><br>

        <label for="name_re">Name:</label><br>
        <input type="text" id="event_name" name="name_re"><br><br>
        
        <input type="submit" name="add_event" value="ADD">
        <h2>SEARCH NAME</h2>
<form method="post">
    <input type="text" name="search" placeholder="Name">
    <input type="submit" value="Search">
</form>
    </form>



<div class="events-table-container">
    <table>
        <style>h1{text-align = center;}</style>
        <h1>Event List</h1>
        <tr>
            <th>Event ID</th>
            <th>Event Name</th>
            <th>Date Added</th>
            <th>Event Location</th>
            <th>Event Description</th>
            <th>Name</th>
            <th>Actions</th>
        </tr>
        <?php
        if (isset($result) && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['event_id'] . "</td>";
                echo "<td>" . $row['event_name'] . "</td>";
                echo "<td>" . $row['event_date'] . "</td>";
                echo "<td>" . $row['event_location'] . "</td>";
                echo "<td>" . $row['event_description'] . "</td>";
                echo "<td>" . $row['name_re'] . "</td>";
                echo "<td>";
                echo "<form action='update.php' method='get' class='actions-form''>"; 
                echo "<input type='hidden' name='edit' value='" . $row['event_id'] . "'>";
                echo "<button type='submit' name='edit_event' style='background-color: #ADD8E6; color: #fff; border: none; padding: 10px 15px; cursor: pointer; border-radius: 20px;'>Edit  </button>"; 
                echo "</form>";

                echo "<form action='' method='post' class='actions-form' style='display: inline-block;'>"; 
                echo "<input type='hidden' name='event_id' value='" . $row['event_id'] . "'>";
                echo "<button type='submit' name='delete_event' style='background-color: #F6A34A; color: #fff; border: none; padding: 10px 15px; cursor: pointer; border-radius: 20px;'>Delete</button>"; 
                echo "</form>";

                echo "<form action='participants.php' method='get'>";
                echo "<input type='hidden' name='event_id' value='" . $row['event_id'] . "'>";
                echo "<button type='submit' name='view_participants' style='background-color: #FFD700; color: #000; border: none; padding: 10px 15px; cursor: pointer; border-radius: 20px;'>Participants</button>";
                echo "</form>";

                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No events found.</td></tr>";
        }
        ?>
    </table>
</div>
</body>
</html>

<?php
if (isset($result) && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr style='background-color: #fff;'>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['event_id']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['event_name']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['event_date']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['event_location']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['event_description']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>".$row['name_re']."</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>";

        echo "<form action='update.php' method='get'>"; 
        echo "<input type='hidden' name='edit' value='".$row['event_id']."'>"; 
        echo "<button type='submit' name='edit_event'>Edit</button>";
        echo "</form>";


        echo "<form action='' method='post'>";
        echo "<input type='hidden' name='event_id' value='".$row['event_id']."'>";
        echo "<button type='submit' name='delete_event'>Delete</button>";
        echo "</form>";

        echo "<form action='events.php' method='get'>";
        echo "<input type='hidden' name='event_id' value='".$row['event_id']."'>";
        echo "<button type='submit' name='view_participants'>Participants</button>";
        echo "</form>"; 

        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr style='background-color: #fff;'><td colspan='7' style='padding: 8px; border: 1px solid #ddd;'>No events found.</td></tr>";
}
?>