<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Participants List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url("bg2.jpg");
            background-color: #cccccc;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: transparent;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: transparent;
            color: #333;
            text-align: left;
        }
        tr:hover {
            background-color: #FF76AF;
        }
        .back-button {
            display: block;
            margin-bottom: 20px;
            background-color: #D9216E;
            color: #fff;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .back-button:hover {
            background-color: #FF76A3;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="#" class="back-button" onclick="history.go(-1);">Back</a>

    <?php
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "event_management";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
    if(isset($_GET['event_id'])) {
        
        $event_id = $_GET['event_id'];
        $sql = "SELECT * FROM eventparticipants WHERE event_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $event_id);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<h2>Participants for Event ID: $event_id</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Participant ID</th><th>Name</th><th>Email</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row['participant_id']."</td>";
                echo "<td>".$row['participant_name']."</td>";
                echo "<td>".$row['participant_email']."</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No participants found for Event ID: $event_id</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Event ID not provided</p>";
    }

    $conn->close();
    ?>
</div>

</body>
</html>
