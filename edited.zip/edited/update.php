<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "event_management";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['update_event'])) {
            // Handle updating an event
            $p_event_id = $_POST['event_id'] ?? '';
            $p_event_name = $_POST['event_name'] ?? '';
            $p_event_location = $_POST['event_location'] ?? '';
            $p_event_description = $_POST['event_description'] ?? '';
            $p_name_re = $_POST['name_re'] ?? '';


            $stmt_update = $conn->prepare("UPDATE events SET event_name=?, event_location=?, event_description=?, name_re=? WHERE event_id=?");
            $stmt_update->bind_param("ssssi", $p_event_name, $p_event_location, $p_event_description, $p_name_re, $p_event_id);

            if ($stmt_update->execute()) {
                echo "Event updated successfully.";
                header("Location: events.php");
                exit(); 
            } else {
                echo "Error updating event: " . $stmt_update->error;
            }
            $stmt_update->close();
        } elseif (isset($_POST['delete_event'])) {
            $event_id = $_POST['event_id'] ?? '';

            $stmt_delete = $conn->prepare("DELETE FROM events WHERE event_id = ?");
            $stmt_delete->bind_param("i", $event_id);

            if ($stmt_delete->execute()) {
                echo "Event deleted successfully.";
                header("Location: events.php");
                exit(); 
            } else {
                echo "Error deleting event: " . $stmt_delete->error;
            }
            $stmt_delete->close();
        } else {
            echo "Invalid action. Please provide a valid action to update or delete the event.";
        }
    }
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
}

$search_query = "";
if (isset($_POST['search'])) {
    $search_query = $_POST['search'];
}

// Retrieve events data with search filter
$sql = "SELECT * FROM events WHERE name_re LIKE '%$search_query%'";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event</title>
    <link rel="stylesheet" type="text/css" href="updatestyles.css">
    
</head>
<body>

    <?php
    if (isset($_GET['edit']) && !empty($_GET['edit'])) {
        // Retrieve the event ID from the URL
        $event_id = $_GET['edit'];

        // Retrieve existing event details based on the event ID
        $sql = "SELECT * FROM `events` WHERE `event_id` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $event_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the event details
            $row = $result->fetch_assoc();
    ?>
    <form action="" method="post">
        <h1>Update Event</h1>
        <input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
        <label for="event_name">Event Name:</label><br>
        <input type="text" id="event_name" name="event_name" value="<?php echo $row['event_name']; ?>"><br><br>

        <label for="event_location">Event Location:</label><br>
        <input type="text" id="event_location" name="event_location" value="<?php echo $row['event_location']; ?>"><br><br>

        <label for="event_description">Event Description:</label><br>
        <textarea id="event_description" name="event_description"><?php echo $row['event_description']; ?></textarea><br><br>

        <label for="name_re">Name:</label><br>
        <input type="text" id="name_re" name="name_re" value="<?php echo $row['name_re']; ?>"><br><br>

        <input type="submit" name="update_event" value="Update">
    </form>
    <?php
        } else {
            echo "Error: Event not found.";
        }
        // Close prepared statement
        $stmt->close();
    } else {
        echo "Error: Event ID not provided.";
    }
    ?>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
